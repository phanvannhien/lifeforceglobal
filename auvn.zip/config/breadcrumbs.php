<?php

return [

	//'view' => 'breadcrumbs::bootstrap3',
	'view' => 'front/partials/breadcrumbs',

];

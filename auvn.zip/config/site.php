<?php 

	return [
		'currency' => ' $',
		'currency_position' => 'before', // before or after
		'upload_path' => 'media/product/images'

	];
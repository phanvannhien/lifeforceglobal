/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'et', {
	fontSize: {
		label: 'Suurus',
		voiceLabel: 'Kirja suurus',
		panelTitle: 'Suurus'
	},
	label: 'Kiri',
	panelTitle: 'Kiri',
	voiceLabel: 'Kiri'
} );
